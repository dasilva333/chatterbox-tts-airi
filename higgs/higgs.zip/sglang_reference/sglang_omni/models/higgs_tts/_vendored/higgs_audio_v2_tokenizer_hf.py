# SPDX-License-Identifier: Apache-2.0
"""Vendored ``HiggsAudioV2TokenizerConfig`` / ``HiggsAudioV2TokenizerModel``.

Upstream reference: https://github.com/huggingface/transformers/pull/40294
"""

import math
from dataclasses import dataclass
from functools import lru_cache

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchaudio
from transformers import AutoConfig, DacConfig, HubertConfig, WavLMConfig
from transformers.configuration_utils import PretrainedConfig
from transformers.utils import ModelOutput, logging

# Patch vs. upstream: ``transformers<5`` doesn't ship the ``initialization``
# module. Route everything to ``torch.nn.init`` and add ``copy_`` (the only
# call in this file that isn't already in torch's namespace).
try:  # pragma: no cover - only true on transformers>=5
    from transformers import initialization as init  # type: ignore[attr-defined]
except ImportError:
    import torch.nn.init as _torch_init

    class _InitShim:
        @staticmethod
        def copy_(dst: torch.Tensor, src: torch.Tensor) -> None:
            dst.copy_(src)

        def __getattr__(self, name: str):
            return getattr(_torch_init, name)

    init = _InitShim()

from transformers.modeling_utils import PreTrainedAudioTokenizerBase
from transformers.models.auto import AutoModel

logger = logging.get_logger(__name__)


def conv1d_output_length(module: "torch.nn.Conv1d", input_length: int) -> int:
    """
    Computes the output length of a 1D convolution layer according to torch's documentation:
    https://docs.pytorch.org/docs/stable/generated/torch.nn.Conv1d.html
    """
    return int(
        (
            input_length
            + 2 * module.padding[0]
            - module.dilation[0] * (module.kernel_size[0] - 1)
            - 1
        )
        / module.stride[0]
        + 1
    )


class HiggsAudioV2TokenizerConfig(PretrainedConfig):
    r"""
    This is the configuration class to store the configuration of an [`HiggsAudioV2TokenizerModel`]. It is used to instantiate a
    HiggsAudioV2Tokenizer model according to the specified arguments, defining the model architecture. Instantiating a configuration
    with the defaults will yield a similar configuration to that of the [`Higgs Audio v2 Tokenizer`](https://huggingface.co/bosonai/higgs-audio-v2-tokenizer).
    e.g. [bosonai/higgs-audio-v2-tokenizer](https://huggingface.co/bosonai/higgs-audio-v2-tokenizer)

    Configuration objects inherit from [`PreTrainedConfig`] and can be used to control the model outputs. Read the
    documentation from [`PreTrainedConfig`] for more information.

    Args:
            target_bandwidths (`List[float]`, *optional*, defaults to `[0.5, 1, 1.5, 2, 4]`):
                The range of different bandwidths (in kbps) the model can encode audio with.
            sample_rate (`int`, *optional*, defaults to 16000):
                The sampling rate at which the audio waveform should be digitalized, in hertz (Hz).
            kernel_size (`int`, *optional*, defaults to 3):
                Kernel size for the initial semantic convolution.
            channel_ratios (`List[float]`, *optional*, defaults to `[1, 1]`):
                Expansion factors for the number of output channels in each semantic block.
            strides (`List[int]`, *optional*, defaults to `[1, 1]`):
                Strides for each semantic encoder block.
            block_dilations (`List[int]`, *optional*, defaults to `[1, 1]`):
                Dilation factors for the residual units in semantic blocks.
            unit_kernel_size (`int`, *optional*, defaults to 3):
                Kernel size inside each ResidualUnit in semantic blocks.
            codebook_size (`int`, *optional*, defaults to 1024):
                Number of entries in each residual quantizer's codebook.
            codebook_dim (`int`, *optional*):
                Dimensionality of each codebook vector. Defaults to sum of hidden size of acoustic and semantic models.
            initializer_range (`float`, *optional*, defaults to 0.02):
                Standard deviation of the truncated normal initializer for all weight matrices.
            acoustic_model_config (`Union[Dict, DacConfig]`, *optional*):
                An instance of the configuration for the acoustic (DAC) model.
            semantic_model_config (`Union[Dict, HubertConfig, WavLMConfig]`, *optional*):
                An instance of the configuration object for the semantic (HuBERT) model.

    Example:

    ```python
    >>> from transformers import HiggsAudioV2TokenizerModel, HiggsAudioV2TokenizerConfig

    >>> # Initializing configuration
    >>> configuration = HiggsAudioV2TokenizerConfig()

    >>> # Initializing a model (with random weights) from the configuration
    >>> model = HiggsAudioV2TokenizerModel(configuration)

    >>> # Accessing the model configuration
    >>> configuration = model.config
    ```"""

    model_type = "higgs_audio_v2_tokenizer"

    sub_configs = {
        "acoustic_model_config": DacConfig,
        "semantic_model_config": AutoConfig,
    }

    def __init__(
        self,
        target_bandwidths=None,
        sample_rate=24000,
        kernel_size=3,
        channel_ratios=[1, 1],
        strides=[1, 1],
        block_dilations=[1, 1],
        unit_kernel_size=3,
        codebook_size=1024,
        codebook_dim=None,
        initializer_range=0.02,
        acoustic_model_config=None,
        semantic_model_config=None,
        semantic_sample_rate=16000,
        downsample_factor=320,
        **kwargs,
    ):
        if acoustic_model_config is None:
            self.acoustic_model_config = DacConfig(
                encoder_hidden_size=64,
                # NOTE: original DAC uses [2, 4, 8, 8] `downsampling ratios`, namely reverse of `upsampling_ratios`
                # (not sure if intentional by HiggsAudioV2Tokenizer but we keep it)
                downsampling_ratios=[8, 5, 4, 2],
                decoder_hidden_size=1024,
                upsampling_ratios=[8, 5, 4, 2],
                hidden_size=256,
            )
        elif isinstance(acoustic_model_config, dict):
            self.acoustic_model_config = DacConfig(**acoustic_model_config)
        elif isinstance(acoustic_model_config, DacConfig):
            self.acoustic_model_config = acoustic_model_config
        else:
            raise ValueError(
                f"acoustic_model_config must be a dict or DacConfig instance, but got {type(acoustic_model_config)}"
            )

        if semantic_model_config is None:
            self.semantic_model_config = HubertConfig()
        elif isinstance(semantic_model_config, dict):
            if "_name_or_path" in semantic_model_config:
                # If the config is a path, load it using AutoConfig
                self.semantic_model_config = AutoConfig.from_pretrained(
                    semantic_model_config["_name_or_path"]
                )
            else:
                # assume HubertConfig as probably created from scratch
                logger.warning(
                    "Could not determine semantic model type from config architecture. Defaulting to `HubertConfig`."
                )
                self.semantic_model_config = HubertConfig(**semantic_model_config)
        elif isinstance(semantic_model_config, WavLMConfig) or isinstance(
            semantic_model_config, HubertConfig
        ):
            self.semantic_model_config = semantic_model_config
        else:
            raise ValueError(
                f"semantic_model_config must be a dict, HubertConfig, or WavLMConfig instance, but got {type(semantic_model_config)}"
            )

        if target_bandwidths is None:
            target_bandwidths = [0.5, 1, 1.5, 2, 4]

        self.target_bandwidths = target_bandwidths
        self.sample_rate = sample_rate
        self.kernel_size = kernel_size
        self.channel_ratios = channel_ratios
        self.strides = strides
        self.block_dilations = block_dilations
        self.unit_kernel_size = unit_kernel_size
        self.codebook_size = codebook_size
        self.initializer_range = initializer_range
        if codebook_dim is None:
            codebook_dim = (
                self.acoustic_model_config.hidden_size
                + self.semantic_model_config.hidden_size
            )
        self.codebook_dim = codebook_dim

        super().__init__(**kwargs)

        self.semantic_sample_rate = semantic_sample_rate
        self.downsample_factor = downsample_factor

    @property
    def frame_rate(self) -> float:
        return self.sample_rate / self.hop_length

    @property
    def semantic_hidden_size(self) -> int:
        return self.semantic_model_config.hidden_size

    @property
    def hop_length(self) -> int:
        return int(np.prod(self.acoustic_model_config.downsampling_ratios))

    @property
    def codebook_nbits(self) -> int:
        return math.ceil(math.log2(self.codebook_size))

    @property
    def hidden_size(self) -> int:
        return (
            self.acoustic_model_config.hidden_size
            + self.semantic_model_config.hidden_size
        )

    @property
    def num_quantizers(self) -> int:
        return int(
            1000 * self.target_bandwidths[-1] // (self.frame_rate * self.codebook_nbits)
        )

    @property
    def semantic_downsample_factor(self):
        return int(
            self.hop_length
            / (self.sample_rate / self.semantic_sample_rate)
            / self.downsample_factor
        )


class HiggsAudioV2TokenizerPreTrainedModel(PreTrainedAudioTokenizerBase):
    """
    An abstract class to handle weights initialization and a simple interface for downloading and loading pretrained
    models.
    """

    config_class = HiggsAudioV2TokenizerConfig
    base_model_prefix = "higgs_audio_v2_tokenizer"
    main_input_name = "input_values"
    input_modalities = "audio"
    _no_split_modules = ["HiggsAudioV2TokenizerResidualVectorQuantization"]

    @torch.no_grad()
    def _init_weights(self, module):
        """Initialize the weights"""
        if isinstance(module, nn.Linear):
            init.normal_(module.weight, mean=0.0, std=self.config.initializer_range)
            if module.bias is not None:
                init.zeros_(module.bias)
        elif isinstance(module, (nn.LayerNorm, nn.GroupNorm)):
            init.zeros_(module.bias)
            init.ones_(module.weight)
        elif isinstance(module, nn.Conv1d):
            init.kaiming_normal_(module.weight)
            if module.bias is not None:
                k = math.sqrt(
                    module.groups / (module.in_channels * module.kernel_size[0])
                )
                init.uniform_(module.bias, a=-k, b=k)
        elif module.__class__.__name__ == "Snake1d":
            init.ones_(module.alpha)
        elif isinstance(module, nn.ConvTranspose1d):
            module.reset_parameters()
        elif isinstance(module, nn.Embedding):
            init.normal_(module.weight, mean=0.0, std=0.02)
        elif isinstance(module, HiggsAudioV2TokenizerModel):
            # The conv1d are not handled correctly, as `self.acoustic_encoder/decoder` are initialized from a PreTrainedModel,
            # but then only the submodules are used (which are not PreTrainedModels...) -> here we reinit them as in DacModel
            for submodule in module.acoustic_encoder.modules():
                if isinstance(submodule, nn.Conv1d):
                    init.trunc_normal_(submodule.weight, std=0.02)
                    init.constant_(submodule.bias, 0)
            for submodule in module.acoustic_decoder.modules():
                if isinstance(submodule, nn.Conv1d):
                    init.trunc_normal_(submodule.weight, std=0.02)
                    init.constant_(submodule.bias, 0)
        elif isinstance(module, HiggsAudioV2TokenizerEuclideanCodebook):
            init.copy_(module.inited, torch.Tensor([True]))
            init.zeros_(module.cluster_size)
            init.zeros_(module.embed)
            init.zeros_(module.embed_avg)

    def apply_weight_norm(self):
        """Apply weight norm in the acoustic encoder and decoder because the original checkpoint has weight norm applied."""
        weight_norm = torch.nn.utils.weight_norm
        if hasattr(torch.nn.utils.parametrizations, "weight_norm"):
            weight_norm = torch.nn.utils.parametrizations.weight_norm

        weight_norm(self.acoustic_encoder.conv1)
        weight_norm(self.acoustic_encoder.conv2)

        for block in self.acoustic_encoder.block:
            weight_norm(block.conv1)
            for res_unit in (block.res_unit1, block.res_unit2, block.res_unit3):
                weight_norm(res_unit.conv1)
                weight_norm(res_unit.conv2)

        weight_norm(self.acoustic_decoder.conv1, name="weight")
        weight_norm(self.acoustic_decoder.conv2, name="weight")

        for block in self.acoustic_decoder.block:
            weight_norm(block.conv_t1, name="weight")
            for res_unit in (block.res_unit1, block.res_unit2, block.res_unit3):
                weight_norm(res_unit.conv1, name="weight")
                weight_norm(res_unit.conv2, name="weight")

    def remove_weight_norm(self):
        """Remove the weight norm from the acoustic encoder and decoder."""
        for module in (self.acoustic_encoder, self.acoustic_decoder):
            for m in module.modules():
                try:
                    torch.nn.utils.remove_weight_norm(m, name="weight")
                except (ValueError, AttributeError):
                    pass
                if hasattr(m, "parametrizations") and "weight" in m.parametrizations:
                    torch.nn.utils.parametrize.remove_parametrizations(
                        m, "weight", leave_parametrized=True
                    )

    @lru_cache
    def _get_conv1d_layers(self, module):
        """
        Recursively iterate to fetch all Conv1d layers.
        """

        def get_conv1d_layers_recursive(module: nn.Module):
            params_list = []

            if isinstance(module, nn.Conv1d):
                params_list.append(module)

            # Recursively check all child modules
            for child in module.children():
                params_list.extend(get_conv1d_layers_recursive(child))

            return params_list

        return tuple(get_conv1d_layers_recursive(module))

    def _get_conv1d_output_lengths(self, input_length, module=None):
        """
        For a given module, compute the output length that would be obtained after all Conv1d layers.
        """
        if module is None:
            module = self

        conv1d_layers = self._get_conv1d_layers(module)

        for layer in conv1d_layers:
            input_length = conv1d_output_length(layer, input_length)

        return input_length


class HiggsAudioV2TokenizerEuclideanCodebook(nn.Module):
    """Codebook with Euclidean distance."""

    def __init__(self, config):
        super().__init__()
        embed = torch.zeros(config.codebook_size, config.codebook_dim)
        self.codebook_size = config.codebook_size
        self.register_buffer("inited", torch.Tensor([True]))
        self.register_buffer("cluster_size", torch.zeros(config.codebook_size))
        self.register_buffer("embed", embed)
        self.register_buffer("embed_avg", embed.clone())

    def quantize(self, hidden_states):
        embed = self.embed.t()
        scaled_states = hidden_states.pow(2).sum(1, keepdim=True)
        dist = -(
            scaled_states
            - 2 * hidden_states @ embed
            + embed.pow(2).sum(0, keepdim=True)
        )
        embed_ind = dist.max(dim=-1).indices
        return embed_ind

    def encode(self, hidden_states):
        shape = hidden_states.shape
        hidden_states = hidden_states.reshape((-1, shape[-1]))
        embed_ind = self.quantize(hidden_states)
        embed_ind = embed_ind.view(*shape[:-1])
        return embed_ind

    def decode(self, embed_ind):
        quantized = F.embedding(embed_ind.to(self.embed.device), self.embed)
        return quantized


class HiggsAudioV2TokenizerVectorQuantization(nn.Module):
    def __init__(self, config: HiggsAudioV2TokenizerConfig):
        super().__init__()
        self.codebook = HiggsAudioV2TokenizerEuclideanCodebook(config)
        self.project_in = nn.Linear(config.hidden_size, config.codebook_dim)
        self.project_out = nn.Linear(config.codebook_dim, config.hidden_size)

    def encode(self, hidden_states):
        hidden_states = hidden_states.permute(0, 2, 1)
        hidden_states = self.project_in(hidden_states)
        embed_in = self.codebook.encode(hidden_states)
        return embed_in

    def decode(self, embed_ind):
        quantize = self.codebook.decode(embed_ind)
        quantize = self.project_out(quantize)
        quantize = quantize.permute(0, 2, 1)
        return quantize


@dataclass
class HiggsAudioV2TokenizerOutput(ModelOutput):
    """
    Args:
        audio_codes (`torch.LongTensor`  of shape `(batch_size, num_quantizers, codes_length)`, *optional*):
            Discrete code indices computed using `model.encode`.
        audio_values (`torch.FloatTensor` of shape `(batch_size, channels, num_samples)`, *optional*)
            Decoded audio values obtained using the decoder part of HiggsAudioV2Tokenizer.
    """

    audio_codes: torch.LongTensor | None = None
    audio_values: torch.FloatTensor | None = None


@dataclass
class HiggsAudioV2TokenizerEncoderOutput(ModelOutput):
    """
    Args:
        audio_codes (`torch.LongTensor`  of shape `(batch_size, num_quantizers, codes_length)`, *optional*):
            Discrete code indices computed using `model.encode`.
    """

    audio_codes: torch.LongTensor | None = None


@dataclass
class HiggsAudioV2TokenizerDecoderOutput(ModelOutput):
    """
    Args:
        audio_values (`torch.FloatTensor`  of shape `(batch_size, channels, num_samples)`, *optional*):
            Decoded audio values obtained using the decoder part of HiggsAudioV2Tokenizer.
    """

    audio_values: torch.FloatTensor | None = None


class HiggsAudioV2TokenizerResidualUnit(nn.Module):
    """Residual block for SemanticEncoder and SemanticDecoder used in HiggsAudioV2Tokenizer."""

    def __init__(
        self,
        config: HiggsAudioV2TokenizerConfig,
        in_channels: int,
        out_channels: int,
        dilation: int,
    ):
        super().__init__()
        self.activation = nn.ELU()
        padding = ((config.unit_kernel_size - 1) // 2) * dilation
        self.conv1 = nn.Conv1d(
            in_channels,
            out_channels,
            config.unit_kernel_size,
            stride=1,
            padding=padding,
            dilation=dilation,
            groups=1,
            bias=False,
        )
        self.conv2 = nn.Conv1d(
            in_channels=out_channels,
            out_channels=out_channels,
            kernel_size=1,
            bias=False,
        )

    def forward(self, hidden_state: torch.Tensor) -> torch.Tensor:
        output_tensor = self.activation(hidden_state)
        output_tensor = self.conv1(output_tensor)
        output_tensor = self.activation(output_tensor)
        output_tensor = self.conv2(output_tensor)
        return hidden_state + output_tensor


class HiggsAudioV2TokenizerSemanticEncoderBlock(nn.Module):
    def __init__(
        self,
        config: HiggsAudioV2TokenizerConfig,
        in_channels: int,
        out_channels: int,
        stride: int,
    ):
        super().__init__()
        self.res_units = nn.ModuleList(
            [
                HiggsAudioV2TokenizerResidualUnit(
                    config, in_channels, in_channels, dilation
                )
                for dilation in config.block_dilations
            ]
        )

        # special case: stride=1, do not use kernel=2
        kernel = 3 if stride == 1 else (2 * stride)
        padding = (kernel - 1) // 2
        self.conv = nn.Conv1d(
            in_channels,
            out_channels,
            kernel_size=kernel,
            stride=stride,
            padding=padding,
            bias=True,
        )

    def forward(self, hidden_state: torch.Tensor) -> torch.Tensor:
        for unit in self.res_units:
            hidden_state = unit(hidden_state)
        hidden_state = self.conv(hidden_state)
        return hidden_state


class SemanticEncoder(nn.Module):
    def __init__(self, config):
        super().__init__()
        if len(config.strides) != len(config.channel_ratios):
            raise ValueError(
                "Number of strides must match the number of channel_ratios."
            )
        self.conv = nn.Conv1d(
            config.semantic_hidden_size,
            config.semantic_hidden_size,
            config.kernel_size,
            1,
            config.kernel_size // 2,
            bias=False,
        )

        in_channels = config.semantic_hidden_size
        conv_blocks = []
        for i, stride in enumerate(config.strides):
            out_channels = int(config.semantic_hidden_size * config.channel_ratios[i])
            conv_blocks += [
                HiggsAudioV2TokenizerSemanticEncoderBlock(
                    config, in_channels, out_channels, stride
                )
            ]
            in_channels = out_channels

        self.conv_blocks = nn.ModuleList(conv_blocks)

    def forward(self, hidden_state: torch.Tensor) -> torch.Tensor:
        hidden_state = self.conv(hidden_state)
        for block in self.conv_blocks:
            hidden_state = block(hidden_state)
        return hidden_state


class SemanticDecoderBlock(nn.Module):
    def __init__(
        self,
        config: HiggsAudioV2TokenizerConfig,
        in_channels: int,
        out_channels: int,
        stride: int,
    ):
        super().__init__()
        if stride == 1:
            self.conv = nn.Conv1d(
                in_channels,
                out_channels,
                kernel_size=3,
                stride=1,
                padding=1,
                bias=True,
            )
        else:
            kernel_size = 2 * stride
            padding = (stride + 1) // 2
            output_padding = 1 if stride % 2 == 1 else 0
            self.conv = nn.ConvTranspose1d(
                in_channels,
                out_channels,
                kernel_size,
                stride,
                padding,
                output_padding,
                bias=False,
            )

        self.res_units = nn.ModuleList(
            [
                HiggsAudioV2TokenizerResidualUnit(
                    config, out_channels, out_channels, dilation
                )
                for dilation in config.block_dilations
            ]
        )

    def forward(self, hidden_state: torch.Tensor) -> torch.Tensor:
        hidden_state = self.conv(hidden_state)
        for unit in self.res_units:
            hidden_state = unit(hidden_state)
        return hidden_state


class SemanticDecoder(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.conv1 = nn.Conv1d(
            in_channels=config.semantic_hidden_size,
            out_channels=int(config.semantic_hidden_size * config.channel_ratios[0]),
            kernel_size=config.kernel_size,
            stride=1,
            padding=config.kernel_size // 2,
            bias=False,
        )
        conv_blocks = []
        for i, stride in enumerate(config.strides):
            in_channels = int(config.semantic_hidden_size * config.channel_ratios[i])

            if i < (len(config.channel_ratios) - 1):
                out_channels = int(
                    config.semantic_hidden_size * config.channel_ratios[i + 1]
                )
            else:
                out_channels = config.semantic_hidden_size

            conv_blocks += [
                SemanticDecoderBlock(config, in_channels, out_channels, stride)
            ]

        self.conv_blocks = nn.ModuleList(conv_blocks)
        self.conv2 = nn.Conv1d(
            config.semantic_hidden_size,
            config.semantic_hidden_size,
            config.kernel_size,
            stride=1,
            padding=config.kernel_size // 2,
            bias=False,
        )

    def forward(self, hidden_state: torch.Tensor) -> torch.Tensor:
        hidden_state = self.conv1(hidden_state)
        for block in self.conv_blocks:
            hidden_state = block(hidden_state)
        hidden_state = self.conv2(hidden_state)
        return hidden_state


class HiggsAudioV2TokenizerResidualVectorQuantization(nn.Module):
    """
    Residual vector quantization implementation. Follows Algorithm 1 in https://huggingface.co/papers/2107.03312
    """

    def __init__(self, config: HiggsAudioV2TokenizerConfig):
        super().__init__()
        self.quantizers = nn.ModuleList(
            [
                HiggsAudioV2TokenizerVectorQuantization(config)
                for _ in range(config.num_quantizers)
            ]
        )
        self.frame_rate = config.frame_rate
        self.codebook_size = config.codebook_size
        self.num_quantizers = config.num_quantizers

    def get_bandwidth_per_quantizer(self):
        """Return bandwidth per quantizer."""
        return math.log2(self.codebook_size) * self.frame_rate / 1000

    def get_num_quantizers_for_bandwidth(self, bandwidth=None) -> int:
        """Return num_quantizers based on specified target bandwidth."""
        bw_per_q = self.get_bandwidth_per_quantizer()
        num_quantizers = self.num_quantizers
        if bandwidth is not None and bandwidth > 0.0:
            num_quantizers = int(max(1, math.floor(bandwidth / bw_per_q)))
        return num_quantizers

    def encode(self, embeddings: torch.Tensor, bandwidth=None) -> torch.Tensor:
        """
        Encode the input tensor into discrete indices using RVQ, with the number of quantizers selected based on the given bandwidth.
        Each quantizer /codebook residually quantizes the input and returns the nearest indices in terms of Euclidian distance.
        """
        num_quantizers = self.get_num_quantizers_for_bandwidth(bandwidth)
        residual = embeddings
        all_indices = []
        for quantizer in self.quantizers[:num_quantizers]:
            indices = quantizer.encode(residual)
            quantized = quantizer.decode(indices)
            residual = residual - quantized
            all_indices.append(indices)
        out_indices = torch.stack(all_indices)
        return out_indices

    def decode(self, codes: torch.Tensor) -> torch.Tensor:
        """Decode the given codes to their quantized representation."""
        quantized_out = torch.tensor(0.0, device=codes.device)
        for i, indices in enumerate(codes):
            quantizer = self.quantizers[i]
            quantized = quantizer.decode(indices)
            quantized_out = quantized_out + quantized.to(codes.device)
        return quantized_out


class HiggsAudioV2TokenizerModel(HiggsAudioV2TokenizerPreTrainedModel):
    def __init__(self, config):
        super().__init__(config)
        self.config = config
        self.pad = config.hop_length // 2
        acoustic_model = AutoModel.from_config(config.acoustic_model_config)
        self.acoustic_encoder = acoustic_model.encoder
        self.acoustic_decoder = acoustic_model.decoder
        self._adjust_dac_decoder(self.acoustic_decoder)
        self.encoder_semantic = SemanticEncoder(config)
        self.decoder_semantic = SemanticDecoder(config)
        self.semantic_model = AutoModel.from_config(config.semantic_model_config).eval()
        self.fc = nn.Linear(config.hidden_size, config.hidden_size)
        self.fc1 = nn.Linear(
            config.hidden_size, config.semantic_model_config.hidden_size
        )
        self.fc2 = nn.Linear(
            config.hidden_size, config.acoustic_model_config.hidden_size
        )
        self.quantizer = HiggsAudioV2TokenizerResidualVectorQuantization(config)

        # Initialize weights and apply final processing
        self.post_init()

    @staticmethod
    def _adjust_dac_decoder(decoder: nn.Module):
        r"""
        DAC implemented in HiggsAudioV2Tokenizer is slightly different from the HF version.
        DAC in HiggsAudioV2Tokenizer adjusts the output padding in every ConvTranspose1d in the decoder and removes
        the final `nn.Tanh` activation function.
        """
        for module in decoder.modules():
            if isinstance(module, nn.ConvTranspose1d):
                stride = (
                    module.stride[0]
                    if isinstance(module.stride, tuple)
                    else module.stride
                )
                module.output_padding = (stride % 2,)
        if hasattr(decoder, "tanh") and isinstance(decoder.tanh, nn.Tanh):
            decoder.tanh = nn.Identity()

    def _extract_semantic_features(
        self, input_values: torch.FloatTensor
    ) -> torch.FloatTensor:
        if self.config.sample_rate != self.config.semantic_sample_rate:
            input_values = torchaudio.functional.resample(
                input_values, self.config.sample_rate, self.config.semantic_sample_rate
            )

        input_values = input_values[:, 0, :]
        # TODO: there is a diff here with original codebase https://github.com/boson-ai/higgs-audio/blob/f644b62b855ba2b938896436221e01efadcc76ca/boson_multimodal/audio_processing/higgs_audio_v2_tokenizer.py#L173-L174
        # input_values = F.pad(input_values, (self.pad, self.pad))
        input_values = F.pad(input_values, (160, 160))
        with torch.no_grad():
            outputs = self.semantic_model(input_values, output_hidden_states=True)
            hidden_states = outputs.hidden_states

        stacked = torch.stack([h.to(input_values.device) for h in hidden_states], dim=1)
        semantic_features = stacked.mean(dim=1)

        if self.config.semantic_downsample_factor > 1:
            semantic_features = semantic_features[
                :, :: self.config.semantic_downsample_factor, :
            ]

        return semantic_features

    def encode(
        self,
        input_values: torch.Tensor,
        bandwidth: float | None = None,
        return_dict: bool | None = None,
    ) -> torch.Tensor | HiggsAudioV2TokenizerEncoderOutput:
        r"""
        input_values (`torch.FloatTensor` of shape `(batch_size, channels, num_samples)`):
            Float values of the input audio waveform.
        bandwidth (`float`, *optional*):
            The target bandwidth in (kbps) supports only values in `config.target_bandwidths`.
            Defaults to the highest available bandwidth `4.0` kbps.
        return_dict (`bool`, *optional*):
            Whether or not to return a [`~utils.ModelOutput`].

        Returns:
            `torch.LongTensor` of shape `(batch_size, num_quantizers, codes_length)` containing the discrete encoded audio codes.
        """
        return_dict = (
            return_dict if return_dict is not None else self.config.return_dict
        )

        channels = input_values.shape[1]
        if channels != 1:
            raise ValueError(f"Audio must be mono, but got {channels}")

        if bandwidth is None:
            bandwidth = self.config.target_bandwidths[-1]
        elif bandwidth not in self.config.target_bandwidths:
            raise ValueError(
                f"This model doesn't support the bandwidth {bandwidth}. Select one of {self.config.target_bandwidths}."
            )

        e_semantic_input = self._extract_semantic_features(input_values).detach()
        e_semantic = self.encoder_semantic(e_semantic_input.transpose(1, 2))

        # original codebase infer to get the output length, but we can directly infer it
        # from the model and know whether we should pad
        if (
            self._get_conv1d_output_lengths(
                input_values.shape[2], self.acoustic_encoder
            )
            != e_semantic.shape[2]
        ):
            e_acoustic = self.acoustic_encoder(
                F.pad(input_values, (self.pad, self.pad))
            )
        else:
            e_acoustic = self.acoustic_encoder(input_values)

        embeddings = torch.cat([e_acoustic.to(e_semantic.device), e_semantic], dim=1)
        embeddings = self.fc(embeddings.transpose(1, 2)).transpose(1, 2)
        audio_codes = self.quantizer.encode(embeddings, bandwidth)
        audio_codes = audio_codes.transpose(0, 1)

        if not return_dict:
            return audio_codes

        return HiggsAudioV2TokenizerEncoderOutput(audio_codes)

    def decode(
        self,
        audio_codes: torch.Tensor,
        return_dict: bool | None = None,
    ) -> torch.Tensor | HiggsAudioV2TokenizerDecoderOutput:
        r"""
        audio_codes (`torch.LongTensor`  of shape `(batch_size, num_quantizers, codes_length)`):
            Discrete code indices computed using `model.encode`.
        return_dict (`bool`, *optional*):
            Whether or not to return a [`~utils.ModelOutput`]

        Returns:
            Decoded audio values of shape `(batch_size, channels, num_samples)` obtained using the decoder part of
            HiggsAudioV2Tokenizer.
        """
        return_dict = (
            return_dict if return_dict is not None else self.config.return_dict
        )

        audio_codes = audio_codes.transpose(0, 1)
        quantized = self.quantizer.decode(audio_codes)
        quantized_acoustic = self.fc2(quantized.transpose(1, 2)).transpose(1, 2)
        audio_values = self.acoustic_decoder(quantized_acoustic)

        if not return_dict:
            return audio_values

        return HiggsAudioV2TokenizerDecoderOutput(audio_values)

    def forward(
        self,
        input_values: torch.Tensor,
        audio_codes: torch.Tensor | None = None,
        bandwidth: float | None = None,
        return_dict: bool | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor] | HiggsAudioV2TokenizerOutput:
        r"""
        input_values (`torch.FloatTensor` of shape `(batch_size, channels, num_samples)`):
            The raw float values of the input audio waveform.
        audio_codes (`torch.LongTensor`  of shape `(batch_size, num_quantizers, codes_length)`:
            Discrete code indices computed using `model.encode`.
        bandwidth (`float`, *optional*):
            Target bandwidth in kbps. Must be one of `config.target_bandwidths`. Defaults to the highest available bandwidth.
        bandwidth (`float`, *optional*):
            Target bandwidth in kbps. Must be one of `config.target_bandwidths`. Defaults to the highest available bandwidth.
        return_dict (`bool`, *optional*):
            Whether to return a [`HiggsAudioV2TokenizerOutput`] instead of a plain tuple.

        Returns:
            `HiggsAudioV2TokenizerOutput` or tuple `(audio_codes, audio_values)`:
            - `audio_codes` of shape `(batch_size, num_quantizers, codes_length)`: the quantized discrete codes.
            - `audio_values` of shape `(batch_size, channels, num_samples)`: the reconstructed audio waveform given the codes.

        Example:

        ```python
        >>> from datasets import load_dataset
        >>> from transformers import AutoFeatureExtractor, HiggsAudioV2TokenizerModel

        >>> model_id = "hf-audio/higgs_audio_v2_tokenizer-hubert-librispeech"
        >>> model = HiggsAudioV2TokenizerModel.from_pretrained(model_id)
        >>> feature_extractor = AutoFeatureExtractor.from_pretrained(model_id)

        >>> dataset = load_dataset("hf-internal-testing/librispeech_asr_dummy", "clean", split="validation")
        >>> dataset = dataset.cast_column("audio", Audio(sampling_rate=feature_extractor.sampling_rate))
        >>> audio_sample = dataset[0]['audio']['array']

        >>> inputs = feature_extractor(raw_audio=audio_sample, return_tensors="pt")

        >>> outputs = model(**inputs)
        >>> audio_codes = outputs.audio_codes
        >>> audio_values = outputs.audio_values
        ```
        """
        return_dict = (
            return_dict if return_dict is not None else self.config.return_dict
        )
        length = input_values.shape[-1]

        if audio_codes is None:
            audio_codes = self.encode(input_values, bandwidth, return_dict=False)

        audio_values = self.decode(audio_codes, return_dict=return_dict)[0][
            ..., :length
        ]

        if not return_dict:
            return (audio_codes, audio_values)

        return HiggsAudioV2TokenizerOutput(
            audio_codes=audio_codes, audio_values=audio_values
        )


__all__ = [
    "HiggsAudioV2TokenizerPreTrainedModel",
    "HiggsAudioV2TokenizerModel",
    "HiggsAudioV2TokenizerConfig",
]
